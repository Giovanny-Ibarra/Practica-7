/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaz;

/**
 *
 * Esta es la clase Circulo de la practica 8
 * @author Giovanny Sanchez, Eduardo Javier Mejia
 */
public class Flauta extends InstrumentoViento {

    public Flauta() {
    }
    /**
     * 
     * @return Flauta de tipo String.
     */
     
    @Override
    public String tipoInstrumento(){
        return "Flauta";
    }

    @Override
    public String toString() {
        return "Flauta{" + '}';
    }
    
    
    
}
