/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herencia;

/**
 *
 * Esta es la clase Circulo de la practica 8
 * @author Giovanny Sanchez, Eduardo Javier Mejia
 */
public class Poligono {

    public Poligono() {
    }
    /**
     * 
     * @return 0 de tipo float
     */
    
    public float area(){
        return 0;
    }
    /**
     * 
     * @return perimetro de tipo float
     */
    public float perimetro(){
        return 0;
    }

    @Override
    public String toString() {
        return "Poligono{" + '}';
    }
    
    
}
