/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AtributosInterfaz;

/**
 *
 * Esta es la clase Circulo de la practica 8 
 * @author Giovanny Sanchez, Eduardo Javier Mejia
 */
public interface Meses {
    //Atributos son: 
        //public static final
    
    int UNO = 1, DOS = 2, TRES = 3, CUATRO = 4, CINCO = 5, SEIS = 6;
    int SIETE = 7, OCHO = 8, NUEVE = 9, DIEZ = 10, ONCE = 11, DOCE = 12;
    
    String[] NOMBRE_MESES = {"", "enero","febrero","marzo","abril","mayo","junio",
        "julio","agosto","septiembre","octubre","noviembre","diciembre"};
}
