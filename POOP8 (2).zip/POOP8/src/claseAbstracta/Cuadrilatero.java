/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package claseAbstracta;

/**
 * Esta es la clase Circulo de la practica 8
 * @author Giovanny Sanchez, Eduardo Javier Mejia
 * 
 */
public class Cuadrilatero extends Poligono {
    private int alpha, beta;
    private float a, b, base, altura;

    public Cuadrilatero() {
    }
    /**
     * 
     * @param alpha de tipo int
     * @param beta de tipo int
     * @param a de tipo float
     * @param b de tipo float
     * @param base de tipo float
     * @param altura de tipo float
     */

    public Cuadrilatero(int alpha, int beta, float a, float b, float base, float altura) {
        this.alpha = alpha;
        this.beta = beta;
        this.a = a;
        this.b = b;
        this.base = base;
        this.altura = altura;
    }
/**
 * 
 * @return alpha de tipo int
 */
    public int getAlpha() {
        return alpha;
    }

    public void setAlpha(int alpha) {
        this.alpha = alpha;
    }
/**
 * 
 * @return beta de tipo int
 */
    public int getBeta() {
        return beta;
    }

    public void setBeta(int beta) {
        this.beta = beta;
    }
/**
 * 
 * @return a de tipo float
 */
    public float getA() {
        return a;
    }

    public void setA(float a) {
        this.a = a;
    }
/**
 * 
 * @return b de tipo float
 */
    public float getB() {
        return b;
    }

    public void setB(float b) {
        this.b = b;
    }
/**
 * 
 * @return base de tipo float
 */
    public float getBase() {
        return base;
    }

    public void setBase(float base) {
        this.base = base;
    }
/**
 * 
 * @return altura de tipo float
 */
    public float getAltura() {
        return altura;
    }

    public void setAltura(float altura) {
        this.altura = altura;
    }

    @Override
    public String toString() {
        return "Cuadrilatero{" + "alpha=" + alpha + ", beta=" + beta + ", a=" + a + ", b=" + b + ", base=" + base + ", altura=" + altura + '}';
    }
    
    @Override
    public float area(){
        return base * altura; 
    }
    
    @Override
    public float perimetro(){
        return 2 * a + 2 * b;
    }
    
}
